# Gun > 2024-05-31 2:11am
https://universe.roboflow.com/gun-emae8/gun-g8zjn

Provided by a Roboflow user
License: CC BY 4.0

